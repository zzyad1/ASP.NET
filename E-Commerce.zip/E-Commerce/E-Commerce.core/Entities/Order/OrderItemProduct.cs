﻿namespace E_Commerce.core.Entities.Order
{
    public class OrderItemProduct
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductUrl { get; set; }
    }
}